#!/usr/bin/env python3
"""
MT_DECOMPOSITION - Python Version
Moment tensor decomposition and visualization

Python implementation based on original MATLAB code by Václav Vavryčuk
Version: 1.0
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from matplotlib.colors import LinearSegmentedColormap, Normalize
import matplotlib.cm as cm
from scipy.interpolate import griddata
import json
import os
from pathlib import Path

class MTDecomposition:
    def __init__(self, config_file='config.json'):
        """Initialize MT decomposition with configuration"""
        with open(config_file, 'r') as f:
            self.config = json.load(f)
        
        # Create output directories if they don't exist
        for path in [self.config['output']['figures_dir'], 
                     os.path.dirname(self.config['output']['results_file'])]:
            Path(path).mkdir(parents=True, exist_ok=True)
    
    def angles(self, m):
        """
        Calculate fault normal and slip from moment tensor
        Returns: strike1, dip1, rake1, strike2, dip2, rake2
        """
        # Eigenvalues and eigenvectors
        eigenvalues, eigenvectors = np.linalg.eig(m)
        
        # Sort eigenvalues and eigenvectors
        idx = eigenvalues.argsort()[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]
        
        # Isotropic part
        volumetric = np.trace(m) / 3.0
        m_volumetric = volumetric * np.eye(3)
        
        # Deviatoric part
        m_deviatoric = m - m_volumetric
        
        # Eigenvalues of deviatoric part
        dev_eigenvalues, dev_eigenvectors = np.linalg.eig(m_deviatoric)
        
        # Sort deviatoric eigenvalues
        idx = dev_eigenvalues.argsort()
        dev_eigenvalues = dev_eigenvalues[idx]
        dev_eigenvectors = dev_eigenvectors[:, idx]
        
        # Calculate fault normal and slip
        n1 = dev_eigenvectors[:, 2] + dev_eigenvectors[:, 0]
        n1 = n1 / np.linalg.norm(n1)
        
        if n1[2] > 0:
            n1 = -n1
            
        u1 = dev_eigenvectors[:, 2] - dev_eigenvectors[:, 0]
        u1 = u1 / np.linalg.norm(u1)
        
        if (n1 @ m @ u1 + u1 @ m @ n1) < 0:
            u1 = -u1
            
        n2 = u1
        u2 = n1
        
        if n2[2] > 0:
            n2 = -n2
            u2 = -u2
            
        # First solution
        dip1 = np.arccos(-n1[2]) * 180 / np.pi
        strike1 = np.arcsin(-n1[0] / np.sqrt(n1[0]**2 + n1[1]**2)) * 180 / np.pi
        
        if n1[1] < 0:
            strike1 = 180 - strike1
            
        rake1 = np.arcsin(-u1[2] / np.sin(dip1 * np.pi / 180)) * 180 / np.pi
        
        cos_rake = u1[0] * np.cos(strike1 * np.pi / 180) + u1[1] * np.sin(strike1 * np.pi / 180)
        if cos_rake < 0:
            rake1 = 180 - rake1
            
        if strike1 < 0:
            strike1 += 360
        if rake1 < -180:
            rake1 += 360
        if rake1 > 180:
            rake1 -= 360
            
        # Second solution
        dip2 = np.arccos(-n2[2]) * 180 / np.pi
        strike2 = np.arcsin(-n2[0] / np.sqrt(n2[0]**2 + n2[1]**2)) * 180 / np.pi
        
        if n2[1] < 0:
            strike2 = 180 - strike2
            
        rake2 = np.arcsin(-u2[2] / np.sin(dip2 * np.pi / 180)) * 180 / np.pi
        
        cos_rake = u2[0] * np.cos(strike2 * np.pi / 180) + u2[1] * np.sin(strike2 * np.pi / 180)
        if cos_rake < 0:
            rake2 = 180 - rake2
            
        if strike2 < 0:
            strike2 += 360
        if rake2 < -180:
            rake2 += 360
        if rake2 > 180:
            rake2 -= 360
            
        return strike1, dip1, rake1, strike2, dip2, rake2
    
    def decompose_mt(self, m):
        """
        Decompose moment tensor into ISO, CLVD, and DC components
        Based on Vavryčuk (2015, Eqs 6-8)
        """
        eigenvalues = np.linalg.eigvals(m)
        eigenvalues = np.sort(eigenvalues)[::-1]
        
        M1, M2, M3 = eigenvalues
        
        # Components
        iso_ = (M1 + M2 + M3) / 3
        clvd_ = 2 * (M1 + M3 - 2*M2) / 3
        dc_ = 0.5 * (M1 - M3 - abs(M1 + M3 - 2*M2))
        
        # Normalization
        s = abs(M1 + M2 + M3)/3 + 2*abs(M1 + M3 - 2*M2)/3 + 0.5*(M1 - M3 - abs(M1 + M3 - 2*M2))
        
        iso = iso_ / s
        clvd = clvd_ / s
        dc = dc_ / s
        
        return iso, clvd, dc
    
    def classify_mechanisms(self, strikes, dips, rakes):
        """
        Classify focal mechanisms into strike-slip, normal, or reverse
        Based on rake angle following Aki & Richards (2002) convention
        """
        mechanisms = np.array(['unknown'] * len(rakes), dtype='<U15')
        
        for i, rake in enumerate(rakes):
            if -180 <= rake <= -150 or 150 <= rake <= 180:
                mechanisms[i] = 'strike-slip'  # Left-lateral
            elif -30 <= rake <= 30:
                mechanisms[i] = 'strike-slip'  # Right-lateral
            elif -120 <= rake <= -60:
                mechanisms[i] = 'normal'
            elif 60 <= rake <= 120:
                mechanisms[i] = 'reverse'
            else:
                # Oblique mechanisms - classify based on dominant component
                if abs(rake) < 45 or abs(rake) > 135:
                    mechanisms[i] = 'strike-slip'
                elif rake < 0:
                    mechanisms[i] = 'normal'
                else:
                    mechanisms[i] = 'reverse'
        
        return mechanisms
    
    def plot_nodal_lines(self, strikes, dips, rakes, filename):
        """Plot nodal lines in lower-hemisphere equal-area projection"""
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_title('Nodal lines', fontsize=16)
        
        # Draw boundary circle
        theta = np.linspace(0, 2*np.pi, 361)
        ax.plot(np.cos(theta), np.sin(theta), 'k', linewidth=1.5)
        ax.plot(0, 0, 'k+', markersize=10)
        
        # Plot nodal lines for each event
        for strike, dip, rake in zip(strikes, dips, rakes):
            # Convert to radians
            strike_rad = strike * np.pi / 180
            dip_rad = dip * np.pi / 180
            rake_rad = rake * np.pi / 180
            
            # Calculate normal and slip vectors
            n1 = np.array([-np.sin(dip_rad) * np.sin(strike_rad),
                           np.sin(dip_rad) * np.cos(strike_rad),
                           -np.cos(dip_rad)])
            
            u1 = np.array([np.cos(rake_rad) * np.cos(strike_rad) + 
                          np.cos(dip_rad) * np.sin(rake_rad) * np.sin(strike_rad),
                          np.cos(rake_rad) * np.sin(strike_rad) - 
                          np.cos(dip_rad) * np.sin(rake_rad) * np.cos(strike_rad),
                          -np.sin(rake_rad) * np.sin(dip_rad)])
            
            # Plot both nodal planes
            for n in [n1, u1]:
                self._plot_single_nodal_line(ax, n)
        
        ax.set_xlim(-1.1, 1.1)
        ax.set_ylim(-1.1, 1.1)
        plt.savefig(filename, dpi=self.config['output']['figure_dpi'], bbox_inches='tight')
        plt.close()
    
    def plot_diamond_blue(self, clvd_values, iso_values, filename):
        """
        Plot CLVD-ISO diamond with blue gradient fill
        MATLAB-style visualization from plot_diamond.m
        """
        # Set up figure
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.set_aspect('equal')
        ax.axis('off')
        
        # Convert to percentage
        clvd_pct = clvd_values * 100
        iso_pct = iso_values * 100
        
        # Define diamond vertices
        diamond_x = np.array([-100, 0, 100, 0, -100])
        diamond_y = np.array([0, -100, 0, 100, 0])
        
        # Create blue gradient colormap
        n_levels = 10
        colour_density = 0.7
        
        # Create blue scale from white to blue
        blue_scale = []
        for i in range(n_levels):
            val = 1.0 - i * colour_density / (n_levels - 1)
            blue_scale.append([val, val, 1.0])  # R, G, B with B=1 always
        
        # Draw filled diamonds from outside to inside
        for i_level in range(n_levels):
            scale = (n_levels - i_level) / n_levels
            x_scaled = scale * diamond_x
            y_scaled = scale * diamond_y
            
            # Create polygon and fill with color
            polygon = plt.Polygon(np.column_stack([x_scaled, y_scaled]), 
                                closed=True, 
                                facecolor=blue_scale[i_level],
                                edgecolor='none')
            ax.add_patch(polygon)
        
        # Draw diamond boundary
        ax.plot(diamond_x, diamond_y, 'b', linewidth=1.5)
        
        # Draw axes
        ax.plot([-100, 100], [0, 0], 'k-', linewidth=1)
        ax.plot([0, 0], [-100, 100], 'k-', linewidth=1)
        
        # Plot data points - MATLAB compatible
        if len(clvd_pct) > 0:
            # MATLAB 'r.' with MarkerSize=18
            # Note: In matplotlib, '.' is a point marker whose size is not affected by markersize
            # For MATLAB compatibility, we use 'o' marker which respects markersize
            # Reduce markersize slightly to avoid overlapping in dense regions
            ax.plot(clvd_pct, iso_pct, 'ro', markersize=6, 
                   markerfacecolor='red', markeredgecolor='none', 
                   zorder=10)
        
        # Labels
        ax.text(107, 0, 'CLVD', fontsize=14, va='center')
        ax.text(-7, 110, 'ISO', fontsize=14, ha='center')
        
        # Set limits
        ax.set_xlim(-120, 120)
        ax.set_ylim(-120, 120)
        
        # Add title
        ax.set_title('CLVD-ISO Diamond Plot', fontsize=16, pad=20)
        
        # Add colorbar at bottom
        # Create a dummy mappable for the colorbar
        
        colors = [[1, 1, 1], [1-colour_density, 1-colour_density, 1]]  # white to blue
        n_bins = 100
        cmap = LinearSegmentedColormap.from_list('blue_gradient', colors, N=n_bins)
        
        # Create colorbar
        sm = plt.cm.ScalarMappable(cmap=cmap, norm=Normalize(vmin=0, vmax=1))
        sm.set_array([])
        cbar_ax = fig.add_axes([0.2, 0.05, 0.6, 0.03])
        cbar = plt.colorbar(sm, cax=cbar_ax, orientation='horizontal')
        cbar.set_ticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
        cbar.set_label('Density Scale', fontsize=12)
        
        plt.savefig(filename, dpi=self.config['output']['figure_dpi'], bbox_inches='tight')
        plt.close()
    
    def _plot_single_nodal_line(self, ax, n):
        """Helper function to plot a single nodal line"""
        n1 = np.sqrt(n[0]**2 + n[1]**2)
        if n1 == 0:
            return
            
        n3 = n[2]
        m1 = n[0] / n1
        m3 = n[1] / n1
        
        if n3 < 0:
            n3 = -n3
            m1 = -m1
            m3 = -m3
            
        ksi = np.linspace(0.1, 360.1, 361)
        x_points = []
        y_points = []
        
        for k in ksi:
            k_rad = k * np.pi / 180
            k1 = np.sin(k_rad)
            k3 = np.cos(k_rad)
            
            smer = -np.array([-k1*m1*n3 + k3*m3, 
                             -(k1*m3*n3 + k3*m1), 
                             k1*n1])
            
            if smer[2] < 0:  # Lower hemisphere only
                theta = np.arccos(k1 * n1) * 180 / np.pi
                
                if theta < 1e-6:
                    continue
                else:
                    sin_fi = smer[0] / np.sin(theta * np.pi / 180)
                    cos_fi = smer[1] / np.sin(theta * np.pi / 180)
                
                x = np.sqrt(2) * np.sin(theta * np.pi / 360) * cos_fi
                y = np.sqrt(2) * np.sin(theta * np.pi / 360) * sin_fi
                
                x_points.append(x)
                y_points.append(y)
            else:
                if len(x_points) > 1:
                    ax.plot(x_points, y_points, 'k', linewidth=1.0)
                x_points = []
                y_points = []
        
        if len(x_points) > 1:
            ax.plot(x_points, y_points, 'k', linewidth=1.0)
    
    def plot_p_t_axes(self, strikes, dips, rakes, filename):
        """Plot P and T axes in lower-hemisphere equal-area projection"""
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.set_aspect('equal')
        ax.axis('off')
        ax.set_title('P(o)/T(+) axes', fontsize=16)
        
        # Draw boundary circle
        theta = np.linspace(0, 2*np.pi, 361)
        ax.plot(np.cos(theta), np.sin(theta), 'k', linewidth=1.5)
        ax.plot(0, 0, 'k+', markersize=10)
        
        # Calculate and plot P and T axes
        p_x, p_y = [], []
        t_x, t_y = [], []
        
        for strike, dip, rake in zip(strikes, dips, rakes):
            # Convert to radians
            strike_rad = strike * np.pi / 180
            dip_rad = dip * np.pi / 180
            rake_rad = rake * np.pi / 180
            
            # Calculate normal and slip vectors
            n1 = np.array([-np.sin(dip_rad) * np.sin(strike_rad),
                           np.sin(dip_rad) * np.cos(strike_rad),
                           -np.cos(dip_rad)])
            
            u1 = np.array([np.cos(rake_rad) * np.cos(strike_rad) + 
                          np.cos(dip_rad) * np.sin(rake_rad) * np.sin(strike_rad),
                          np.cos(rake_rad) * np.sin(strike_rad) - 
                          np.cos(dip_rad) * np.sin(rake_rad) * np.cos(strike_rad),
                          -np.sin(rake_rad) * np.sin(dip_rad)])
            
            # P and T axes
            p_axis = (n1 - u1) / np.linalg.norm(n1 - u1)
            t_axis = (n1 + u1) / np.linalg.norm(n1 + u1)
            
            # Ensure lower hemisphere
            if p_axis[2] > 0:
                p_axis = -p_axis
            if t_axis[2] > 0:
                t_axis = -t_axis
            
            # Project to equal-area
            for axis, x_list, y_list in [(p_axis, p_x, p_y), (t_axis, t_x, t_y)]:
                azimuth = np.arctan2(axis[0], axis[1])
                theta = np.arccos(abs(axis[2])) * 180 / np.pi
                
                x = np.sqrt(2) * np.sin(theta * np.pi / 360) * np.sin(azimuth)
                y = np.sqrt(2) * np.sin(theta * np.pi / 360) * np.cos(azimuth)
                
                x_list.append(x)
                y_list.append(y)
        
        ax.plot(p_y, p_x, 'ro', markersize=10, linewidth=1.5, label='P-axis')
        ax.plot(t_y, t_x, 'b+', markersize=10, linewidth=1.5, mew=2, label='T-axis')
        
        ax.set_xlim(-1.1, 1.1)
        ax.set_ylim(-1.1, 1.1)
        plt.savefig(filename, dpi=150, bbox_inches='tight')
        plt.close()
    
    def plot_diamond_kde(self, clvd_values, iso_values, filename, mechanisms=None):
        """
        Plot CLVD-ISO diamond with kernel density estimation
        Paper-style visualization with black background
        """
        # Set up figure with black background
        fig, ax = plt.subplots(figsize=(8, 8), facecolor='black')
        ax.set_facecolor('black')
        ax.set_aspect('equal')
        ax.axis('off')
        
        # Convert to percentage
        clvd_pct = clvd_values * 100
        iso_pct = iso_values * 100
        
        # Create high-resolution grid for density estimation
        grid_density = 400  # Higher resolution for smoother visualization
        x = np.linspace(-110, 110, grid_density)
        y = np.linspace(-110, 110, grid_density)
        X, Y = np.meshgrid(x, y)
        
        # Create mask for diamond shape
        mask = (np.abs(X) + np.abs(Y)) <= 100
        
        # If we have data, compute density
        if len(clvd_pct) > 0:
            from scipy.stats import gaussian_kde
            
            # Stack the data
            data = np.vstack([clvd_pct, iso_pct])
            
            # Calculate the density with optimized bandwidth
            # Use adaptive bandwidth based on data size
            if len(clvd_pct) < 50:
                bw_method = 0.3  # Larger bandwidth for sparse data
            elif len(clvd_pct) < 200:
                bw_method = 0.2  # Medium bandwidth
            else:
                bw_method = 0.15  # Original bandwidth for dense data
            
            kde = gaussian_kde(data, bw_method=bw_method)
            
            # Evaluate on grid
            positions = np.vstack([X.ravel(), Y.ravel()])
            Z = np.reshape(kde(positions).T, X.shape)
            
            # Apply diamond mask
            Z[~mask] = 0
            
            # Normalize to [0, 1]
            Z_max = np.max(Z)
            if Z_max > 0:
                Z = Z / Z_max
            
            # Apply power transformation to enhance contrast
            # Use lower power for sparse data to make it more visible
            Z = np.power(Z, 0.5)  # Changed from 0.7 to 0.5 for better visibility
            
            # Optional: Apply minimum threshold to make low density areas more visible
            Z[Z > 0.01] = np.maximum(Z[Z > 0.01], 0.1)  # Boost low values
            
            # Create custom colormap similar to the paper
            # Blue -> Cyan -> Yellow -> Red
            colors = [
                (0.0, 0.0, 0.0),      # Black
                (0.0, 0.0, 0.5),      # Dark blue
                (0.0, 0.0, 1.0),      # Blue
                (0.0, 0.5, 1.0),      # Light blue
                (0.0, 1.0, 1.0),      # Cyan
                (0.5, 1.0, 0.5),      # Light green
                (1.0, 1.0, 0.0),      # Yellow
                (1.0, 0.5, 0.0),      # Orange
                (1.0, 0.0, 0.0),      # Red
                (0.5, 0.0, 0.0)       # Dark red
            ]
            n_bins = 256
            cmap = LinearSegmentedColormap.from_list('paper_style', colors, N=n_bins)
            
            # Plot the density
            im = ax.imshow(Z.T, extent=[-110, 110, -110, 110], 
                          origin='lower', cmap=cmap, 
                          interpolation='bilinear', aspect='equal')
            
            # Set proper levels for intensity
            im.set_clim(0, 1)
        
        # Draw diamond boundary in white/light color
        diamond_x = np.array([-100, 0, 100, 0, -100])
        diamond_y = np.array([0, -100, 0, 100, 0])
        ax.plot(diamond_x, diamond_y, 'white', linewidth=2)
        
        # Draw axes in white
        ax.plot([-100, 100], [0, 0], 'white', linewidth=1, alpha=0.5)
        ax.plot([0, 0], [-100, 100], 'white', linewidth=1, alpha=0.5)
        
        # Labels in white
        ax.text(107, 0, 'CLVD', fontsize=14, va='center', color='white')
        ax.text(0, 107, 'ISO', fontsize=14, ha='center', color='white')
        
        # Set limits
        ax.set_xlim(-120, 120)
        ax.set_ylim(-120, 120)
        
        # Add colorbar with white text at bottom
        if len(clvd_pct) > 0:
            # Create colorbar at bottom to avoid overlapping diamond
            cbar_ax = fig.add_axes([0.2, 0.05, 0.6, 0.03])  # [left, bottom, width, height]
            cbar = plt.colorbar(im, cax=cbar_ax, orientation='horizontal')
            cbar.outline.set_color('white')
            cbar.ax.xaxis.set_tick_params(color='white')
            plt.setp(plt.getp(cbar.ax.axes, 'xticklabels'), color='white')
        
        plt.savefig(filename, dpi=self.config['output']['figure_dpi'], bbox_inches='tight', 
                   facecolor='black', edgecolor='none')
        plt.close()
    
    def plot_diamond_kde_by_mechanism(self, clvd_values, iso_values, mechanisms, filename):
        """
        Plot CLVD-ISO diamond with kernel density estimation
        Color-coded by focal mechanism type - Original white background style
        """
        # Set up figure with white background (original style)
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.set_aspect('equal')
        ax.axis('off')
        
        # Convert to percentage
        clvd_pct = clvd_values * 100
        iso_pct = iso_values * 100
        
        # Define colors for different mechanisms
        mech_colors = {
            'strike-slip': 'red',
            'normal': 'green', 
            'reverse': 'blue'
        }
        
        # Create high-resolution grid
        grid_density = 400
        x = np.linspace(-110, 110, grid_density)
        y = np.linspace(-110, 110, grid_density)
        X, Y = np.meshgrid(x, y)
        
        # Create mask for diamond shape
        mask = (np.abs(X) + np.abs(Y)) <= 100
        
        # Compute combined density for background
        if len(clvd_pct) > 0:
            from scipy.stats import gaussian_kde
            
            # Initialize combined density
            Z_combined = np.zeros_like(X)
            
            # Compute density for each mechanism type
            for mech_type in ['strike-slip', 'normal', 'reverse']:
                mask_mech = mechanisms == mech_type
                if np.any(mask_mech):
                    data_mech = np.vstack([clvd_pct[mask_mech], iso_pct[mask_mech]])
                    # Adaptive bandwidth based on data size
                    n_points = np.sum(mask_mech)
                    if n_points < 50:
                        bw = 0.3
                    elif n_points < 200:
                        bw = 0.2
                    else:
                        bw = 0.15
                    kde_mech = gaussian_kde(data_mech, bw_method=bw)
                    positions = np.vstack([X.ravel(), Y.ravel()])
                    Z_mech = np.reshape(kde_mech(positions).T, X.shape)
                    Z_combined += Z_mech
            
            # Apply diamond mask
            Z_combined[~mask] = 0
            
            # Normalize
            if np.max(Z_combined) > 0:
                Z_combined = Z_combined / np.max(Z_combined)
            
            # Apply power transformation
            Z_combined = np.power(Z_combined, 0.5)  # Use 0.5 for better visibility
            
            # Create gray colormap for background density
            colors = ['#ffffff', '#f0f0f0', '#d9d9d9', '#bdbdbd', '#969696',
                     '#737373', '#525252', '#252525']
            cmap = LinearSegmentedColormap.from_list('gray_density', colors, N=100)
            
            # Plot the density background with transparency
            im = ax.contourf(X, Y, Z_combined, levels=20, cmap=cmap, alpha=0.5)
        
        # Draw diamond boundary in black
        diamond_x = np.array([-100, 0, 100, 0, -100])
        diamond_y = np.array([0, -100, 0, 100, 0])
        ax.plot(diamond_x, diamond_y, 'k', linewidth=2)
        
        # Draw axes in black
        ax.plot([-100, 100], [0, 0], 'k-', linewidth=1)
        ax.plot([0, 0], [-100, 100], 'k-', linewidth=1)
        
        # Plot data points by mechanism type
        if len(clvd_pct) > 0 and mechanisms is not None:
            for mech_type, color in mech_colors.items():
                mask_mech = mechanisms == mech_type
                if np.any(mask_mech):
                    ax.scatter(clvd_pct[mask_mech], iso_pct[mask_mech], 
                             c=color, s=40, edgecolors='black', 
                             linewidth=0.5, alpha=0.7, zorder=10,
                             label=mech_type.replace('-', ' ').title())
        
        # Labels in black
        ax.text(107, 0, 'CLVD', fontsize=14, va='center')
        ax.text(0, 107, 'ISO', fontsize=14, ha='center')
        
        # Add percentage labels on axes
        for val in [-100, -50, 0, 50, 100]:
            if val != 0:
                ax.text(val, -5, f'{int(val)}%', fontsize=9, ha='center', va='top')
                ax.text(-5, val, f'{int(val)}%', fontsize=9, ha='right', va='center')
        
        # Set limits
        ax.set_xlim(-120, 120)
        ax.set_ylim(-120, 120)
        
        # Add title
        ax.set_title('CLVD-ISO Decomposition by Focal Mechanism', 
                    fontsize=16, pad=20)
        
        # Add colorbar at bottom (if there's density data)
        if len(clvd_pct) > 0:
            cbar_ax = fig.add_axes([0.2, 0.05, 0.6, 0.03])  # [left, bottom, width, height]
            cbar = plt.colorbar(im, cax=cbar_ax, orientation='horizontal')
            cbar.set_label('Density', fontsize=12)
        
        # Add legend if mechanisms are provided
        if mechanisms is not None:
            ax.legend(loc='upper left', bbox_to_anchor=(0.02, 0.98),
                     frameon=True, facecolor='white', edgecolor='black')
        
        plt.savefig(filename, dpi=150, bbox_inches='tight')
        plt.close()
    
    def run(self):
        """Main execution function"""
        print("MT_DECOMPOSITION - Python Version")
        print("=================================")
        
        # Read input data
        print(f"Reading input file: {self.config['input']['moments_file']}")
        data = np.loadtxt(self.config['input']['moments_file'], comments='%')
        
        if data.ndim == 1:
            data = data.reshape(1, -1)
        
        n_events = data.shape[0]
        print(f"Number of events: {n_events}")
        
        # Initialize result arrays
        results = {
            'strike1': np.zeros(n_events),
            'dip1': np.zeros(n_events),
            'rake1': np.zeros(n_events),
            'strike2': np.zeros(n_events),
            'dip2': np.zeros(n_events),
            'rake2': np.zeros(n_events),
            'dc': np.zeros(n_events),
            'clvd': np.zeros(n_events),
            'iso': np.zeros(n_events)
        }
        
        # Process each event
        print("\nProcessing events...")
        for i in range(n_events):
            # Construct moment tensor
            m = np.array([[data[i, 0], data[i, 5], data[i, 4]],
                         [data[i, 5], data[i, 1], data[i, 3]],
                         [data[i, 4], data[i, 3], data[i, 2]]])
            
            # Decompose moment tensor
            results['iso'][i], results['clvd'][i], results['dc'][i] = self.decompose_mt(m)
            
            # Calculate fault plane solutions
            (results['strike1'][i], results['dip1'][i], results['rake1'][i],
             results['strike2'][i], results['dip2'][i], results['rake2'][i]) = self.angles(m)
            
            print(f"Event {i+1}: DC={results['dc'][i]:.1%}, "
                  f"CLVD={results['clvd'][i]:.1%}, ISO={results['iso'][i]:.1%}")
        
        # Generate plots
        print("\nGenerating plots...")
        figures_dir = self.config['output']['figures_dir']
        
        self.plot_nodal_lines(results['strike1'], results['dip1'], results['rake1'],
                             os.path.join(figures_dir, 'nodal_lines.png'))
        print("  - Nodal lines plot saved")
        
        self.plot_p_t_axes(results['strike1'], results['dip1'], results['rake1'],
                          os.path.join(figures_dir, 'P_T_axes.png'))
        print("  - P/T axes plot saved")
        
        # Generate paper-style kernel density plot
        self.plot_diamond_kde(results['clvd'], results['iso'],
                             os.path.join(figures_dir, 'diamond_plot_kde_paper_style.png'))
        print("  - CLVD-ISO diamond plot (Paper-style KDE) saved")
        
        # Generate MATLAB-style blue gradient plot
        self.plot_diamond_blue(results['clvd'], results['iso'],
                              os.path.join(figures_dir, 'diamond_plot_blue.png'))
        print("  - CLVD-ISO diamond plot (MATLAB-style blue) saved")
        
        # If we can determine focal mechanisms, create color-coded plot
        try:
            mechanisms = self.classify_mechanisms(results['strike1'], results['dip1'], results['rake1'])
            self.plot_diamond_kde(results['clvd'], results['iso'],
                                 os.path.join(figures_dir, 'diamond_plot_kde_paper_style.png'),
                                 mechanisms)
            self.plot_diamond_kde_by_mechanism(results['clvd'], results['iso'], mechanisms,
                                             os.path.join(figures_dir, 'diamond_plot_mechanisms.png'))
            print("  - CLVD-ISO diamond plot by mechanism (Original style) saved")
        except:
            print("  - Could not generate mechanism-specific plot")
        
        # Save results
        print(f"\nSaving results to: {self.config['output']['results_file']}")
        np.savez(self.config['output']['results_file'], **results)
        
        # Also save as text file for convenience
        txt_file = self.config['output']['results_file'].replace('.npz', '.txt')
        with open(txt_file, 'w') as f:
            f.write("# MT Decomposition Results\n")
            f.write("# Event Strike1 Dip1 Rake1 Strike2 Dip2 Rake2 DC(%) CLVD(%) ISO(%)\n")
            for i in range(n_events):
                f.write(f"{i+1:5d} {results['strike1'][i]:7.1f} {results['dip1'][i]:6.1f} "
                       f"{results['rake1'][i]:7.1f} {results['strike2'][i]:7.1f} "
                       f"{results['dip2'][i]:6.1f} {results['rake2'][i]:7.1f} "
                       f"{results['dc'][i]*100:6.1f} {results['clvd'][i]*100:7.1f} "
                       f"{results['iso'][i]*100:7.1f}\n")
        
        print("\nProcessing complete!")
        print(f"Results saved to: {self.config['output']['results_file']}")
        print(f"Text results saved to: {txt_file}")
        print(f"Figures saved to: {figures_dir}/")

if __name__ == "__main__":
    # Run the decomposition
    mt_decomp = MTDecomposition('config.json')
    mt_decomp.run()